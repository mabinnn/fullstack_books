from __future__ import unicode_literals

from django.apps import AppConfig


class BookAppsConfig(AppConfig):
    name = 'book_apps'
